// Import the WebSocket library and create a server
const WebSocket = require('ws');
const server = new WebSocket.Server({ port: 8080 });

// Storage for rooms, their respective users, and chat history
const rooms = { 'General': [] };
const chatHistory = { 'General': [] };
const clients = {};

// Handle new connections to the WebSocket server
server.on('connection', (socket) => {
    console.log('New connection established.');

    socket.on('message', (message) => {
        const data = JSON.parse(message);

        if (data.type === 'join') {
            // Handle user joining a room
            if (!clients[data.username]) {
                clients[data.username] = socket;
                socket.username = data.username;
                socket.room = data.room;

                // Add the user to the room
                if (!rooms[data.room]) {
                    rooms[data.room] = [];
                    chatHistory[data.room] = [];
                }
                rooms[data.room].push(data.username);

                // Broadcast that the user has joined the room
                broadcastMessage(socket.room, {
                    type: 'notification',
                    message: `${data.username} has joined the room.`,
                    timestamp: Date.now()
                });

                // Send the chat history of the room to the user
                socket.send(JSON.stringify({ type: 'history', messages: chatHistory[data.room] }));

                // Broadcast the updated room list to all clients
                broadcastRooms();
            } else {
                // Handle user switching rooms
                const oldRoom = socket.room;
                if (oldRoom !== data.room) {
                    const index = rooms[oldRoom].indexOf(data.username);
                    if (index !== -1) {
                        rooms[oldRoom].splice(index, 1);

                        // Broadcast that the user has left the old room
                        broadcastMessage(oldRoom, {
                            type: 'notification',
                            message: `${data.username} has left the room.`,
                            timestamp: Date.now()
                        });
                    }

                    socket.room = data.room;
                    if (!rooms[data.room]) {
                        rooms[data.room] = [];
                        chatHistory[data.room] = [];
                    }
                    rooms[data.room].push(data.username);

                    // Broadcast that the user has joined the new room
                    broadcastMessage(data.room, {
                        type: 'notification',
                        message: `${data.username} has joined the room.`,
                        timestamp: Date.now()
                    });

                    // Send the chat history of the new room to the user
                    socket.send(JSON.stringify({ type: 'history', messages: chatHistory[data.room] }));

                    // Broadcast the updated room list to all clients
                    broadcastRooms();
                }
            }
        } else if (data.type === 'create') {
            // Handle creation of a new room
            if (!rooms[data.room]) {
                rooms[data.room] = [];
                chatHistory[data.room] = [];
                broadcastRooms();
            }
        } else if (data.type === 'message') {
            // Broadcast messages to all users in the same room and save it to the history
            const timestamp = Date.now();
            const room = data.room || socket.room;
            const messageData = {
                type: 'message',
                username: data.username,
                message: data.message,
                timestamp
            };
            chatHistory[room].push(messageData);
            rooms[room].forEach(user => {
                if (clients[user]) {
                    clients[user].send(JSON.stringify(messageData));
                }
            });
        }
    });

    // Handle user disconnection
    socket.on('close', () => {
        if (socket.username) {
            const room = socket.room;
            const index = rooms[room].indexOf(socket.username);
            if (index !== -1) {
                rooms[room].splice(index, 1);
                delete clients[socket.username];

                // Broadcast that the user has left the room
                broadcastMessage(room, {
                    type: 'notification',
                    message: `${socket.username} has left the room.`,
                    timestamp: Date.now()
                });

                broadcastRooms();
            }
        }
        console.log('Connection closed.');
    });
});

// Function to broadcast the list of rooms to all clients
function broadcastRooms() {
    const roomNames = Object.keys(rooms);
    Object.values(clients).forEach(client => {
        client.send(JSON.stringify({ type: 'rooms', rooms: roomNames }));
    });
}

// Function to broadcast a message to all users in a room
function broadcastMessage(room, message) {
    rooms[room].forEach(user => {
        if (clients[user]) {
            clients[user].send(JSON.stringify(message));
        }
    });
}
