// Event listener for joining the chat
document.getElementById('join-chat').addEventListener('click', () => {
    const username = sanitizeInput(document.getElementById('username').value.trim());
    if (username) {
        // Store username in local storage for session persistence
        localStorage.setItem('username', username);
        // Hide authentication section and show chat room
        document.getElementById('auth').classList.add('hidden');
        document.getElementById('chat-room').classList.remove('hidden');
        initializeChat(username);
    } else {
        alert('Please enter a valid username');
    }
});

// Initialize the chat functionality
function initializeChat(username) {
    // Establish a WebSocket connection to the server
    const socket = new WebSocket('ws://localhost:8080');
    const messagesDiv = document.getElementById('messages');
    const roomsUl = document.getElementById('rooms');

    socket.addEventListener('open', () => {
        console.log('Connected to the server');

        // Join the default room 'General'
        let currentRoom = 'General';
        socket.send(JSON.stringify({ type: 'join', room: currentRoom, username }));

        // Handle incoming messages, room updates, and chat history
        socket.addEventListener('message', (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'message') {
                displayMessage(data, username);
            } else if (data.type === 'rooms') {
                updateRooms(data.rooms);
            } else if (data.type === 'history') {
                displayHistory(data.messages, username);
            } else if (data.type === 'notification') {
                displayNotification(data.message);
            }
        });

        // Event listener for creating a new room
        document.getElementById('create-room').addEventListener('click', () => {
            const newRoom = sanitizeInput(document.getElementById('new-room').value.trim());
            if (newRoom) {
                socket.send(JSON.stringify({ type: 'create', room: newRoom }));
                document.getElementById('new-room').value = ''; // Clear the input field
            }
        });

        // Event listener for joining an existing room
        roomsUl.addEventListener('click', (event) => {
            if (event.target.tagName === 'LI') {
                const room = event.target.innerText;
                // Highlight the active room
                document.querySelectorAll('#rooms-list li').forEach(li => li.classList.remove('active'));
                event.target.classList.add('active');
                socket.send(JSON.stringify({ type: 'join', room, username }));
                currentRoom = room;
                messagesDiv.innerHTML = ''; // Clear previous messages
            }
        });

        // Event listener for sending messages
        document.getElementById('send-message').addEventListener('click', () => {
            const messageInput = document.getElementById('message-input');
            const message = sanitizeInput(messageInput.value.trim());
            if (message) {
                socket.send(JSON.stringify({ type: 'message', message, room: currentRoom, username }));
                messageInput.value = ''; // Clear the message input field
            }
        });
    });

    socket.addEventListener('close', () => {
        alert('Disconnected from server');
        console.log('Disconnected from the server');
    });
}

// Function to display messages in the chat area
function displayMessage(data, username) {
    const messagesDiv = document.getElementById('messages');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message');
    if (data.username === username) {
        messageElement.classList.add('self');
    }
    messageElement.innerHTML = `<strong>${data.username}</strong>: ${data.message} <em>${new Date(data.timestamp).toLocaleTimeString()}</em>`;
    messagesDiv.appendChild(messageElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

// Function to display chat history
function displayHistory(messages, username) {
    messages.forEach(message => {
        displayMessage(message, username);
    });
}

// Function to display notifications in the chat area
function displayNotification(message) {
    const messagesDiv = document.getElementById('messages');
    const notificationElement = document.createElement('div');
    notificationElement.classList.add('notification');
    notificationElement.innerHTML = `<em>${message}</em>`;
    messagesDiv.appendChild(notificationElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

// Function to update the list of available rooms
function updateRooms(rooms) {
    const roomsUl = document.getElementById('rooms');
    roomsUl.innerHTML = '';
    rooms.forEach(room => {
        const roomElement = document.createElement('li');
        roomElement.innerText = room;
        roomsUl.appendChild(roomElement);
    });
}

// Utility function to sanitize user input
function sanitizeInput(input) {
    const element = document.createElement('div');
    element.innerText = input;
    return element.innerHTML;
}
